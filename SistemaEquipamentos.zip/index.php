<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Index</title>
</head>
<body>
	<form method="post" action="usuarios/validacoes/validar_login.php">
		<input type="text" name="usuario" placeholder="Login"><br>
		<input type="password" name="senha" placeholder="Senha"><br>
		<input type="submit" name="Entrar">	
	</form>
</body>
</html>
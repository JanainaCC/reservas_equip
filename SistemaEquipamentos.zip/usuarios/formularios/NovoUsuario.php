 <?php
 include "../../Verificasessao.php";
if (!isset($_SESSION)) {
	session_start();
}
date_default_timezone_set('America/Fortaleza');
$date = date('d-m-Y');
?>
<!DOCTYPE html>
<html>
<head>
	<title>formulário</title>
</head>
	<body>
		<table>
			<tr>
				<td> <?php echo $_SESSION['nome_usuario']; ?></td>
				<td> <?php echo $date; ?> </td> 
				<td> <a href="../../inicio.php">Página Inicial</a></td>
				<td> <a href="../../sair.php">SAIR</a></td>
			</tr>
		</table>
		<br>
		<a href="javascript:history.back()">VOLTAR</a>
		<h4>CADASTRO DE USUÁRIOS</h4>
		<form method="post" action="../validacoes/validar_NovoCadastro.php">
			<table>
				<tr>
					<td> Nome: </td> <td> <input type="text" name="nome" required></td>
				</tr>
				<tr>
					<td> Usuário: </td> <td><input type="text" name="usuario" maxlength="15" required></td>
				</tr>
				<tr>
					<td> Senha: </td><td><input type="password" name="senha" maxlength="20" required></td>
				</tr>
				<tr>
					<td> Nivel: </td>
				<td>
					<select name="nivel" required>
						<option value="1">Desenvolvedor</option>
						<option value="2">Administrador</option>
						<option value="3">Controle de Reservas</option>
						<option value="4">Professor</option>
					</select>
				</td>
				</tr>
				<br>
				<tr>
				<td></td>
					<td><input type="submit" value="cadastrar" >
						<input type="reset" value="limpar"></td>
				</tr>
			</table>	
		</form>
	</body>
</html>

<?php
include "../../Verificasessao.php";
include '../../conexao.php';
if (!isset($_SESSION)) {
	session_start();
}
date_default_timezone_set('America/Fortaleza');
$data_inicio = $_POST['dataInicio'];
$temp_c = $_POST['horaInicio'];
$data_fim = $_POST['dataFim'];
$temp_f = $_POST['horaFim'];
$descricao = $_POST['descricao'];
$cod_item = $_REQUEST['codigo'];
$data_hoje = date('Y-m-d');
$cod_usuario = $_SESSION['cod_usuario'];


if ((empty(strtotime($data_inicio))) || (empty(strtotime($temp_c))) || (empty(strtotime($data_fim))) || (empty(strtotime($temp_f))) || (empty($descricao)) || (empty($cod_item))) {
	echo "<script type='text/javascript'> alert ('DADOS INVÁLIDOS!'); window.location.href='javascript:history.back()'; </script>";
}else{
	if (strtotime($data_inicio) < strtotime($data_hoje)) {
		echo "<script type='text/javascript'> alert ('DATA DE INICIO INVÁLIDA!'); window.location.href='javascript:history.back()'; </script>";
	}else{
		if(strtotime($data_fim) < strtotime($data_inicio)){
			echo "<script type='text/javascript'> alert ('DATA DE FIM INVÁLIDA!'); window.location.href='javascript:history.back()'; </script>";
		}else{
			if ((strtotime($data_inicio) == strtotime($data_fim)) && strtotime($temp_c) > strtotime($temp_f)) {
				echo "<script type='text/javascript'> alert ('HORA DE FIM INVÁLIDA!'); window.location.href='javascript:history.back()'; </script>";	
			}else{
				$sql1 = "SELECT * FROM t_reserva WHERE t_item_cod_item = '$cod_item' AND '$data_inicio' < data_inicio AND '$data_fim' > data_fim";
				$result1 = mysqli_query($conexao, $sql1);
				if(mysqli_num_rows($result1) > 0){
					echo "<script type='text/javascript'> alert ('Não foi possível realizar reserva! Já tem reserva feita nesse intervalo de tempo!'); window.location.href='javascript:history.back()'; </script>";
				}else{
					//$temp_c Hora de inicio fornecida pelo user
					//temp_f Hora final fornecida pelo user
					//hora_incio hora inicial de uma reserva efetuada para este produto
					//hora_fim  hora final de uma reserva efetuada para este produto
					$sql2 = "SELECT * FROM t_reserva WHERE t_item_cod_item = '$cod_item' AND (hora_inicio >= '$temp_c' AND hora_inicio <= '$temp_f') OR (hora_fim >= '$temp_c' AND hora_fim <= '$temp_f') AND cancela_reserva=false"; 
					//OR '$temp_c' >= hora_inicio AND '$temp_f' <= hora_fim OR '$temp_c' < hora_inicio AND '$temp_f' > hora_fim";
					$result2 = mysqli_query($conexao, $sql2);
					if($result2 == true){
						if(mysqli_num_rows($result2) > 0){
							echo "<script type='text/javascript'>alert ('Não foi possível realizar reserva! Já tem reserva feita nesse intervalo de tempo2!'); window.location.href='javascript:history.back()'; </script>";
						}else{
							$sql = "INSERT INTO t_reserva (data_reserva, data_inicio, hora_inicio, data_fim, hora_fim, desc_reserva, t_item_cod_item, t_usuario_cod_usuario) VALUES ('$data_reserva', '$data_inicio', '$temp_c', '$data_fim', '$temp_f', '$descricao','$cod_item','$cod_usuario')";

							mysqli_autocommit($conexao, false);
							$result = mysqli_query($conexao, $sql);
							if (!$result){
								mysqli_close($conexao);
								echo "<script type='text/javascript'>alert ('NÃO FOI POSSIVEL REALIZAR RESERVA!'); window.location.href='javascript:history.back()'; </script>";
							}else{						
								mysqli_commit($conexao);
								mysqli_close($conexao);
								echo "<script type='text/javascript'> alert ('RESERVA REALIZADA COM SUCESSO!'); window.location.href='../itens.php'; </script>";
							}
						}
					}else{
						echo "ERRO!";
					}
				}

				
			}
		}
	}	
}
?>

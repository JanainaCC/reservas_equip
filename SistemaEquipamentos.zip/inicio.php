<?php
include "conexao.php";
if (!isset($_SESSION)) {
	session_start();
}

if (!isset($_SESSION['nome_usuario'])) {
	header('location: index.php');
}else{
	date_default_timezone_set('America/Fortaleza');
	$date = date('d-m-Y');
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Início</title>
	</head>
	<body>
		<?php echo "Usuário:  ".$_SESSION['nome_usuario']; ?> 
		<?php echo $date; ?>
		<a href="sair.php"> SAIR</a><br>
		<a href = 'usuarios/usuarios.php'> USUÁRIOS</a>
		<a href = 'itens/itens.php'> ITENS</a>
		<a href= 'itens/reservas_feitas.php'> MINHAS RESERVAS</a>
	</body>
</html>
<?php
}
?>

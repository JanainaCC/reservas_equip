# 3ano-equipamentos
Projeto do 3º Ano Integrado em Informática do IFPI, Campus Paulistana
